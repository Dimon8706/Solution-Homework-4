package Homework4.part2;

public interface ChatService {
    void sendMessage(String message);
}

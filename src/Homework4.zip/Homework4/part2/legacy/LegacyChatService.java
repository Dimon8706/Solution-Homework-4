package Homework4.part2.legacy;

public class LegacyChatService {
    // The old method we cannot change
    public void sendLegacyMessage(String message) {
        System.out.println("Legacy Chat: " + message);
    }
}
